import sys
from typing import Any
from itertools import combinations
from openfermion import QubitOperator, jordan_wigner
from typing import Optional, Union, Tuple, List, Sequence, Mapping
from quri_parts.openfermion.operator import operator_from_openfermion_op
from quri_parts.circuit.transpile import RZSetTranspiler
from quri_parts.core.operator import (
    pauli_label,
    Operator,
    PauliLabel,
    pauli_product,
    PAULI_IDENTITY,
)
from qutip import qeye, sigmax, sigmay, sigmaz, tensor, Qobj
import pdb
import re
from numpy import linalg as LA


# author: Yongxin Yao (yxphysice@gmail.com)
import itertools, numpy, h5py, os
import scipy.optimize, scipy.linalg, scipy.sparse
import pdb
import re
import time
import multiprocessing
from joblib import Parallel, delayed
import copy
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib import rc
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter



def get_sxyz_ops(nsite):
    '''set up site-wise sx, sy, sz operators.
    '''
    si = qeye(2)
    sx = sigmax()
    sy = sigmay()
    sz = sigmaz()
    sx_list = []
    sy_list = []
    sz_list = []

    op_list = [si for i in range(nsite)]
    for i in range(nsite):
        op_list[i] = sx
        sx_list.append(tensor(op_list))
        op_list[i] = sy
        sy_list.append(tensor(op_list))
        op_list[i] = sz
        sz_list.append(tensor(op_list))
        # reset
        op_list[i] = si
    return [sx_list, sy_list, sz_list]





#from pygrisb.run.timing import timeit
class ansatz():

    def bin2dec(x):
        '''
        converts a string of binary number
        to a integer decimal number
        '''
        x = x.strip()
        d = 0
        n = len(x)
        for i in range(n-1,-1,-1):
            d += float(x[i])*(2**(n-1-i))
        return int(d)

    def construct_string(sind, nq):
        #from model import get_sxyz_ops
        #sops_list = get_sxyz_ops(nq)
        #pdb.set_trace()
        gate = ['I',"X","Y","Z"]
        op_pool = []
        for term in sind:
            op = ''
            #print(term)
            #  Qubit 0 is in the extreme right
            for t in range(len(term)-1,0,-2):
                if term[t]==0:
                    continue
                #op += gate[term[t]]+str(term[t-1])
                #op += sops_list[ term[t]-1 ][ term[t-1] ]
                op += gate[ term[t] ]+str( term[t-1] )
                #op += gate[term[t]]+str(term[t-1])
            op_pool.append(op)

        return op_pool

    def construct_operator(sind, nq):
        #from model import get_sxyz_ops
        sops_list = get_sxyz_ops(nq)
        #pdb.set_trace()
        #gate = ['I',"X","Y","Z"]
        op_pool = []
        for term in sind:
            op = 1
            #print(term)
            # Qubit 0 is in the extreme right
            #for t in range(len(term)-1,0,-2):
            # Qubit 0 is in the extreme left
            for t in range(0, len(term),2):
                if term[t]==0:
                    continue
                #op *= sops_list[ term[t]-1 ][ term[t-1] ]
                op *= sops_list[ term[t+1]-1 ][ term[t] ]
            op_pool.append(op)

        return op_pool


    def construct_single_string(sind, nq):
        #from model import get_sxyz_ops
        #sops_list = get_sxyz_ops(nq)
        #pdb.set_trace()
        term = sind
        gate = ['I',"X","Y","Z"]
        op = ''
        #print(term)
        # Qubit 0 is in the extreme right
        #for t in range(len(term)-1,0,-2):
        for t in range(1,len(term),2):
            if term[t]==0:
                continue
            #op += gate[term[t]]+str(term[t-1])
            #op += sops_list[ term[t]-1 ][ term[t-1] ]
            op += gate[ term[t] ]+str( term[t-1] )
            #op += gate[term[t]]+str(term[t-1])

        return op

    def construct_single_operator(sind, nq):
        #from model import get_sxyz_ops
        sops_list = get_sxyz_ops(nq)
        op = 1
        #print(term)
        # Qubit 0 is in the extreme right
        #for t in range(len(term)-1,0,-2):
        # Qubit 0 is in the extreme left
        for t in range(1, len(sind) ,2):
            if sind[t]==0:
                continue
            #op *= sops_list[ term[t]-1 ][ term[t-1] ]
            op *= sops_list[ sind[t]-1 ][ sind[t-1] ]

        return op


    def build_single_operator_pool(nsite):

        '''
        operator pool for QCC mean field
        '''
        #from model import get_sxyz_ops
        #sops_list = get_sxyz_ops(nq)
        sx_list, sy_list, sz_list = get_sxyz_ops(nsite)
        op_pool = [[],[]]
        th = 0
        #Sx(j)
        for i in range(nsite):
            #op = sz_list[i]
            #op_pool[0].append(th) # [theta_mu, A_mu]
            #op_pool[1].append(op) # [theta_mu, A_mu]

            op = sy_list[i]
            op_pool[0].append(th) # [theta_mu, A_mu]
            op_pool[1].append(op) # [theta_mu, A_mu]
        #print(len(op_pool[0]))

        return op_pool


    def get_psi(ref_state,theta_list, op_pool):
        n = len(ref_state)
        matrix = numpy.eye(n, dtype=numpy.complex)
        for theta, op in zip(theta_list, op_pool):
            op = numpy.asarray(op)
            #arg = -0.5j*theta*op
            arg = -1.0j*theta*op
            matrix = numpy.matmul(scipy.linalg.expm(arg),matrix)
        psi = matrix.dot(ref_state)
        return psi

    def get_exp(op,psi):
        '''
        get operator expectation value wrt psi
        '''
        psi_t = numpy.asarray(op).dot(psi)
        ev = numpy.vdot(psi,psi_t)
        return ev


    def costfunc(theta,op_pool, ref_state, h, h2):
        #psi = get_psi(ref_state, op_pool)
        psi = get_psi(ref_state,theta, op_pool)
        eh = get_exp(h, psi).real
        eh2 = get_exp(h2, psi).real
        #return eh4 - 4*lda*(eh3-eh*eh2) + 4*lda*lda*(eh2-eh*eh)
        #return expectValue(psi, h2).real - expectValue(psi, h).real**2
        #return eh2.real - 2*lda*eh.real + lda**2
        return eh.real

    class spectra_data:
        # data type for more efficient expm calculation.
        # store the dense matrix and spectral representation
        def __init__(self,
                qobj,  # qobj from qutip
                ):
            self._a = qobj.full()
            self._w, self._v = numpy.linalg.eigh(self._a)

        def expm(self, alpha):
            # calculate exp(alpha*a)
            return (self._v*numpy.exp(alpha*self._w)).dot(self._v.T.conj())

        def dot(self, b):
            return self._a.dot(b)

        def matrix_element(self, v, vp):
            return v.conj().dot(self._a.dot(vp))

        def show(self):
            print (numpy.asarray(self._a))

    class spectra_data2:
        # data type for more efficient expm calculation.
        # store the dense matrix and spectral representation
        def __init__(self,
                qobj,  # qobj from qutip
                ):
            self._a = qobj.full()
            #self._w, self._v = numpy.linalg.eigh(self._a)

        def expm(self, alpha):
            # calculate exp(alpha*a)
            return scipy.linalg.expm(alpha*numpy.asarray(self._a))
            #return numpy.exp(alpha*numpy.asarray(self._a))
            #return (self._v*numpy.exp(alpha*self._w)).dot(self._v.T.conj())

        def dot(self, b):
            return self._a.dot(b)

        def matrix_element(self, v, vp):
            return v.conj().dot(self._a.dot(vp))

        def show(self):
            print (numpy.asarray(self._a))

    class ansatz:
        def __init__(self,
                nq,
                ref_state=None,
                order=2,
                rcut=3.e-4,  # McLachlan distance cut-off
                pthcut=5,  # maximal allowed \frac{\par theta}{\par t}
                op_filename = None,
                pool=None,  # pool generation option
                opdense=True,  # operator in dense matrix format
                ):
            self._params = []
            self._op_filename = op_filename
            self._params_init = None
            self._reduced_pool = False
            # stores the A_mu
            self._ansatz = [[], []]
            self._pool = pool
            self.set_order(order)
            self._ngates = [0]*self._order
            self._opdense = opdense
            self._nq = nq
            # ref state is
            self.set_ref_state(ref_state) #
            self._state = None
            self._rcut = rcut
            self._pthcut = pthcut
            self._pthmaxt = 0  # max \frac{\par theta}{\par t}
            self.generate_op_pools()
            #self.h5init() #
  
        def set_order(self, order):
            if self._pool is None:
                self._order = order
            elif self._pool == "XYZ" or self._pool == "-XYZ":
                self._order = 2
            elif self._pool == "H2":
                self._order = 2
            else:
                raise ValueError(f"pool = {self._pool} not available.")

        def h5init(self):
            if os.path.isfile("ansatzi.h5"):
                with h5py.File("ansatzi.h5", "r") as f:
                    self._ref_state = f["/ref_state"][()]
                    if "/ansatz" in f:
                        self._ansatz[0] = f["/ansatz"][()]
                        self._ansatz[1] = f["/ansatz_code"][()]
                        self._params = f["/params"][()]

        def construct_psi0(self):
            self.update_state()
            #self._params_init = self._params[:]
            if self._params_init is None:
                self._params_init = self._params[:]
            else:
                for i in range(len(self._params) - len(self._params_init)):
                    self._params_init.append(0.)

        def show(self):
            '''
            Print the operators used in the ansatz
            '''
            gate = ["I","X","Y","Z"]
            op_pool = []
            #pdb.set_trace()
            for term in self._ansatz[1]:
                op = ''
                for t in range(0,len(term),2):
                    if  term[t+1] == 0:
                        continue
                    op += gate[term[t+1]]+str(term[t])
                op_pool.append(op)
            print(op_pool)
            pass
        #@timeit



        def run_qcc(self,h):
             '''
             Run qubit coupled cluster mean field optimization
            h : original Hamiltonian
            lda: lambda
            the cost function to be minimized is (h-lda)^2
            '''
            op_pool = build_single_operator_pool(self._nq)
            #op_pool[0] = numpy.random.rand(len(op_pool[0]))
            theta = op_pool[0]
            ref_state = numpy.zeros(2**self._nq)
            #ref_state = numpy.ones(2**self._nq)
            ref_state[0] = 1
            norm = numpy.linalg.norm(ref_state)
            ref_state /= norm

            h2 = numpy.matmul(h,h)
            print(f"Number of operators: {len(op_pool[0])}")
    
            psi = get_psi(ref_state,op_pool[0], op_pool[1])
            norm = numpy.vdot(psi,psi)
            print(f"Norm: {norm}")
            eh = get_exp(h, psi).real
            print(f"Initial Energy: {eh}")
            cf = costfunc(op_pool[0], op_pool[1], ref_state, h, h2)
            print(f"Initial Cost: {cf}")

            '''
            Optimize the single qubit pool
            '''
            print("Running QCC .. ")
            res = minimize( costfunc , op_pool[0], \
                  args = ( op_pool[1], ref_state, h, h2, lda ), method='nelder-mead', \
                  options={'maxiter':10000})

            cf_min = res.fun
            op_pool[0] = res.x
            print(f" Final Cost: {cf_min}")
            #print(op_pool[0])
            psi = get_psi(ref_state,op_pool[0], op_pool[1])
            self._ref_state = psi
            #self._state = psi
            norm = numpy.vdot(psi,psi)
            print(f"Final Norm Check: {norm}")
            eh = get_exp(h, psi).real
            #var = get_exp(h2, psi).real - eh*eh
            print(f"Final Energy: {eh}")
            #pdb.set_trace()

            #e_, e_vec = LA.eigh(h)
            #print(e_)
            pass

        def additive_optimize(self, h, e_exact):
            f = open('uccsd.out','w')
            e_data = []
            if self._opdense:
                self._h = spectra_data(h)
            else:
                self._h = h
            self.optimize_params()
            print(f"initial cost = {self._cost:.6f}")
            print(f"initial cost = {self._cost:.6f}",file = f)
            iloop = 0
            while True:
                added = self.add_op()
                if not added:
                    break
                self.optimize_params()
                self.update_state()
                print(f"iter {iloop}: cost = {self._cost:.6f}")
                print(f"iter {iloop}: cost = {self._cost:.6f}",file = f)
                iloop += 1
                e_data.append([iloop,self._cost])
                if abs(self._cost-e_exact[0]) < 1.e-4:
                    break
            #print(f"Number of operators  in the final ansatz: {len(self._ansatz[0]):2.f}")
            print("Number of operators  in the final ansatz:"+ str(len(self._ansatz[0])))
            print("Number of operators  in the final ansatz:"+ str(len(self._ansatz[0])),file = f)
            f.close()
            e_data = numpy.asarray(e_data)
            plt.plot(e_data[:,0],e_data[:,1],'.',label = 'adapt-VQE')
            plt.plot([0,iloop], [e_exact[0], e_exact[0]], 'r--', label = 'Exact 0')
            plt.xlabel('steps')
            plt.ylabel('E')
            plt.show(block=False)
            try:
                input('Hit enter to close')
            except:
                plt.close()
            if self._params_init is None:
                self._params_init = self._params[:]
            else:
                for i in range(len(self._params) - len(self._params_init)):
                    self._params_init.append(0.)
        @property
        def state(self):
            return self._state

        @property
        def ngates(self):
            return self._ngates[:]

        def get_cost(self):
            self.update_state()
            res = self._h.matrix_element(self._state, self._state)
            return res.real

        #@timeit
        def update_state(self):
            self._state = self.get_state()

        def generate_op_pools(self):
            if self._op_filename:
                self._op_pools = generate_op_pool_custom(self._nq,
                        self._order,
                        self._op_filename,
                        self._pool,
                        )
                 #self._op_pools = [self._op_pools]
            else:
                self._op_pools = generate_op_pools(self._nq,
                        self._order,
                        self._pool,
                        )
            if self._opdense:
                t0 = time.time()
                num_cores = multiprocessing.cpu_count()
                #pdb.set_trace()
                #self._op_pools[0][0] = Parallel(n_jobs=num_cores)(delayed(spectra_data2(op)) for op in self._op_pools[0][0])
                for i, op_pool in enumerate(self._op_pools):
                    #self._op_pools[i][0] = [spectra_data(op) for op in op_pool[0]]
                    self._op_pools[i][0] = Parallel(n_jobs=num_cores)\
                                          (delayed(spectra_data)(op) for op in op_pool[0])
                #pdb.set_trace()
                t1 = time.time()
            else:
                t0 = time.time()
                num_cores = multiprocessing.cpu_count()
                #pdb.set_trace()
                #self._op_pools[0][0] = Parallel(n_jobs=num_cores)(delayed(spectra_data2(op)) for op in self._op_pools[0][0])
                for i, op_pool in enumerate(self._op_pools):
                    #self._op_pools[i][0] = [spectra_data2(op) for op in op_pool[0]]
                    self._op_pools[i][0] = Parallel(n_jobs=num_cores)\
                                     (delayed(spectra_data2)(op) for op in op_pool[0])
            t1 = time.time()

        print(f"Operator pool constructed in {t1-t0}sec")

    def set_ref_state(self, ref_state):

        '''
        prepare mixed state of Ising Hamiltonian
        '''


        if  (isinstance(ref_state, numpy.ndarray)) == False :
            #print(ref_state)
            #print(isinstance(ref_state, numpy.ndarray) )
            #pdb.set_trace()
            '''
            Comment out the following two lines to start from a PM state
            '''
            #self._ref_state = numpy.ones((2**self._nq), dtype=numpy.complex)
            #self._ref_state /= 2**self._nq #PM state


            self._ref_state = numpy.zeros((2**self._nq), dtype=numpy.complex)
            idx = bin2dec(ref_state)
            self._ref_state[idx] = 1. # FM state

        else:
            if not isinstance(ref_state, numpy.ndarray):
                ref_state = ref_state.full().reshape(-1)
                self._ref_state = ref_state

    #@timeit
    def optimize_params(self):
        if len(self._params) > 0:
            res = scipy.optimize.minimize(fun_cost,
                    self._params,
                    args=(self._ansatz[0],
                            self._ref_state,
                            self._h,
                            ),
                    method='CG',
                    jac=fun_jac,
                    )
            if res.success:
                self._params = res.x.tolist()
                self._cost = res.fun
            else:
                print(res.message)
        else:
            self._cost = self.get_cost()

    #@timeit
    def add_op(self, tol=1.e-4):
        scores = self.get_pool_scores()
        ids = numpy.argsort(abs(scores))
        iadd = ids[-1]
        print("top 3 scores: "+ \
                f"{' '.join(f'{scores[i]:.2e}' for i in ids[-3:])}")
        if len(self._ansatz[1]) > 0  \
                and numpy.allclose(self._op_pools[0][1][iadd],  \
                self._ansatz[1][-1]):
            # no further improvement
            print(f"abort: pauli ops {self._ansatz[1][-1]}" + \
                    f" vs {self._op_pools[0][1][iadd]}")
            return False
        elif abs(scores[iadd]) < tol:
            print(f"converge: gradient = {scores[iadd]:.2e} too small.")
            return False
        else:
            self._ansatz[0].append(self._op_pools[0][0][iadd])
            # label
            self._ansatz[1].append(self._op_pools[0][1][iadd])
            self.update_ngates()
            print(f"op {self._ansatz[1][-1]} appended.")
            self._params.append(0.)
            return True

    def update_ngates(self):
        iorder = numpy.count_nonzero(self._ansatz[1][-1][1::2])
        self._ngates[iorder-1] += 1

    #@timeit
    def add_ops_dyn(self, mmdfile=None):
        #if self._opdense:
        hvec = self._h.dot(self._state)
        #else:
        #    hvec = self._h*self._state
        icyc = 0
        hvar = self._e2 - self._e**2
        while True:
            np = len(self._params)
            mmat = numpy.zeros((np+1, np+1))
            mmat[:np, :np] = self._mmat
            vvec = numpy.zeros((np+1))
            vvec[:np] = self._vvec
            val_max = self._distp
            pth_max = max(self._pthmax, self._pthcut)
            ichoice = None
            mmat_ch = None
            # <partial_vec|vec_cur>
            #if self._opdense:
            vpv_list = [numpy.vdot(v, self._state)  \
                    for v in self._vecp_list]
            #else:
            #    vpv_list = [v.overlap(self._state) for v in self._vecp_list]
            #print(self._op_pools[-1][0])
            for i, op, label in zip(itertools.count(),
                    self._op_pools[-1][0],
                    self._op_pools[-1][1]):
                # same op is the end one, skip
                if len(self._ansatz[1]) > 0 and  \
                        numpy.allclose(label, self._ansatz[1][-1]):
                    continue
                # mmat addition
                #if self._opdense:
                vecp_add = -0.5j*op.dot(self._state)
                #else:
                #    vecp_add = -0.5j*op*self._state
                #if self._opdense:
                vpv_add = numpy.vdot(vecp_add, self._state)
                acol = [numpy.vdot(v, vecp_add) + vpv*vpv_add  \
                        for v, vpv in zip(self._vecp_list, vpv_list)]
                acol.append(numpy.vdot(vecp_add, vecp_add) +  \
                        vpv_add*vpv_add)
                # vvec addition
                zes = numpy.vdot(vecp_add, hvec)

                #else:
                #    vpv_add = vecp_add.overlap(self._state)
                #    acol = [v.overlap(vecp_add) + vpv*vpv_add  \
                #            for v, vpv in zip(self._vecp_list, vpv_list)]
                #    acol.append(vecp_add.overlap(vecp_add) +  \
                #            vpv_add*vpv_add)
                    # vvec addition
                #    zes = vecp_add.overlap(hvec)

                mmat[:, -1] = numpy.asarray(acol).real
                # upper symmetric part
                mmat[-1, :] = mmat[:, -1]

                # real time
                #vvec[-1] = zes.imag
                #vvec[-1] -= (vpv_add*self._e).imag

                # Imaginary time
                vvec[-1] = -zes.real
                vvec[-1] += (vpv_add*self._e).real
                ## m_inv = numpy.linalg.pinv(mmat)

                m_inv = get_minv(mmat)
                dist_p = (vvec.conj().dot(m_inv).dot(vvec)).real
                pthvec = m_inv.dot(vvec)
                pthmax = numpy.max(numpy.abs(pthvec))

                #print(zes)
                #op.show()
                #print(i,dist_p)
                '''
                if dist_p > val_max + 1e-8 or \
                        (abs(hvar - dist_p) < self._rcut and  \
                        pthmax < pth_max):
                '''
                    # dist drop, larger time step, better condition
                if dist_p > val_max:

                    ichoice = i
                    val_max = dist_p
                    pth_max = pthmax
                    mmat_ch = mmat.copy()
                    vvec_ch = vvec.copy()
                    minv_ch = m_inv.copy()
                    vecp_add_ch = vecp_add.copy()

            dist = hvar - val_max
            diff = val_max - self._distp
            #print(dist)
            #if ichoice is None or  \
            #        (diff < 1.e-8 and pth_max - self._pthmax < 1.e-6):
            if ichoice is None:
                raise ValueError("dynamic ansatz cannot further improve.")
            self._distp = val_max
            self._pthmax = pth_max
            self._mmat = mmat_ch
            self._minv = minv_ch
            self._vvec = vvec_ch
            self._ansatz[0].append(self._op_pools[-1][0][ichoice])
            self._ansatz[1].append(self._op_pools[-1][1][ichoice])
            self.update_ngates()
            self._vecp_list.append(vecp_add_ch)
            self._params.append(0)
            self._params_init.append(0.)

            print(f"pth_max: {pth_max:.6f}")
            print(f"add op: {self._ansatz[1][-1]}")
            print(f"icyc = {icyc}, dist = {dist:.2e}, improving {diff:.2e}")
            #pdb.set_trace()

            if dist < self._rcut and pth_max < self._pthcut:
                break
            icyc += 1
        if mmdfile is not None:
            with open(mmdfile, 'a') as f:
                f.write("Logging specific outputs\n")

    def get_state(self):
        return get_ansatz_state(self._params,
                        self._ansatz[0],
                        self._ref_state,
                        )

    def get_pool_scores(self):
        '''-0.5j <[h,op]> = im(<h op>)
        '''
        scores = []
        #if self._opdense:
        h_vec = self._h.dot(self._state)
        #else:
        #    h_vec = self._h*self._state
        for op in self._op_pools[0][0]:
            #if self._opdense:
            ov = op.dot(self._state)
            zes = numpy.vdot(h_vec, ov)
            #else:
            #    ov = op*self._state
            #    zes = h_vec.overlap(ov)
            scores.append(zes.imag)
        return numpy.array(scores)

    #@timeit
    #@timeit
    def one_step(self, h, dtmax, dthmax, dt, mmdfilename):
        # hamiltoinian
        #from avdynamics.model import _evolution
        #dt = 0.5
        #if self._opdense:
        self._h = spectra_data(h)
        #else:
        #    self._h = spectra_data(h)
            #self._h = spectra_data2(h)
            #self._h = h
        #else:
        #    self._h = h
        self.set_par_states()
        amat = self.get_amat()
        cvec, mp, vp, e, e2 = self.get_cvec_phase()
        # McLachlan's principle, including global phase contribution
        #from avdynamics.model import spinModel.get_evolution
        #from avdynamics.model import HydrogenChain.get_evolution
        #from avdynamics.model import spinModel._evolution
        #pdb.set_trace()
        #evolution = get_evolution()
        evolution = 'I'
        m = amat.real + numpy.asarray(mp).real
        if evolution == "R":
            v = cvec.imag - numpy.asarray(vp).imag
        elif evolution == "I":
            v = -cvec.real + numpy.asarray(vp).real

            #v = cvec.imag - numpy.asarray(vp).imag
            #pdb.set_trace()
            #v = -cvec.real #+ numpy.asarray(vp).real
            #v = cvec.real - numpy.asarray(vp).real
        self._mmat = m
        self._vvec = v
        self._e, self._e2 = e, e2
        # m_inv = numpy.linalg.pinv(m)
        m_inv = get_minv(m)
        # McLachlan distance
        dist_h2 = e2 - e**2
        print("Var: "+str(dist_h2))
        dist_p = (v.conj().dot(m_inv).dot(v)).real
        dist = dist_h2 - dist_p
        self._distp = dist_p
        self._minv = m_inv
        p_params = m_inv.dot(v)
        if len(p_params) > 0:
            pthmax = numpy.max(numpy.abs(p_params))
        else:
            pthmax = 0
        self._pthmax = pthmax
        
        # Handling the mmdfile for logging McLachlan distance and parameters
        if mmdfilename:
            with open(mmdfilename, 'a') as mmdfile:
                mmdfile.write(f"initial MMD= {dist:.10e}\n")
                mmdfile.write(f"initial mcLachlan distance: {dist:.2e} pthmax: {pthmax:.2e}\n")
        
        
        if dist > self._rcut or pthmax > self._pthcut:
            self.add_ops_dyn(mmdfilename)
            
        p_params = self._minv.dot(self._vvec)
        if len(p_params) > 0:
            pthmax = numpy.max(numpy.abs(p_params))
            self._pthmaxt = max(pthmax, self._pthmaxt)
            print(f"max element in p_params: {pthmax:.2f}")
            #dt = 0.01
            # if pthmax > 0:
                # dt = min(dtmax, dthmax/pthmax)
                # dt = dthmax/pthmax

        self._params = [p + pp*dt for p, pp in zip(self._params, p_params)]
        self.update_state()
        norm = self._state.dot(self._state)
        #pdb.set_trace()
        return dt, e, dist_h2, 1/norm
    
    def condition_check(self, msg, tol=1.e-6):
        if minv_error(self._mmat, self._minv) > tol:
            raise ValueError(f"{msg} M matrix inversion error.")

    def get_dist(self):
        return self._e2 - self._e**2 - self._distp

    #@timeit
    def set_par_states(self):
        ''' d |vec> / d theta.
        '''
        np = len(self._params)
        vecp_list = []
        vec_i = self._ref_state
        #if self._opdense:
        for i in range(np):
            th, op = self._params[i], self._ansatz[0][i]
            # factor of 0.5 difference from the main text.
            vec_i = op.expm(-0.5j*th).dot(vec_i)
            vec = -0.5j*op.dot(vec_i)
            for th, op in zip(self._params[i+1:], self._ansatz[0][i+1:]):
                vec = op.expm(-0.5j*th).dot(vec)
            vecp_list.append(vec)
        #else:
        #    for i in range(np):
        #        th, op = self._params[i], self._ansatz[0][i]
        #        opth = -0.5j*th*op
        #        vec_i = opth.expm()*vec_i
        #        vec = -0.5j*op*vec_i
        #        for th, op in zip(self._params[i+1:], self._ansatz[0][i+1:]):
        #            opth = -0.5j*th*op
        #            vec = opth.expm()*vec
        #        vecp_list.append(vec)
        self._vecp_list = vecp_list

    def get_amat(self):
        np = len(self._params)
        amat = numpy.zeros((np, np), dtype=numpy.complex)
        for i in range(np):
            for j in range(i, np):
                #if self._opdense:
                zes = numpy.vdot(self._vecp_list[i], self._vecp_list[j])
                #else:
                #    zes = self._vecp_list[i].overlap(self._vecp_list[j])
                amat[i, j] = zes
                if i != j:
                    # hermitian component
                    amat[j, i] = numpy.conj(zes)
        return amat

    #@timeit
    def get_cvec_phase(self):
        np = len(self._params)
        cvec = numpy.zeros(np, dtype=numpy.complex)
        # h |vec>
        #if self._opdense:
        hvec = self._h.dot(self._state)
        for i in range(np):
            cvec[i] = numpy.vdot(self._vecp_list[i], hvec)
        # energy
        e = numpy.vdot(self._state, hvec).real
        e2 = numpy.vdot(hvec, hvec).real
        # <partial_vec|vec_cur>
        vpv_list = [numpy.vdot(vecp, self._state)  \
                for vecp in self._vecp_list]
        #else:
        #    hvec = self._h*self._state
        #    for i in range(np):
        #        cvec[i] = self._vecp_list[i].overlap(hvec)
        #    # energy
        #    e = (self._state.overlap(hvec)).real
        #    e2 = (hvec.overlap(hvec)).real
            # <partial_vec|vec_cur>
        #    vpv_list = [vecp.overlap(self._state)  \
        #            for vecp in self._vecp_list]
        mp = [[vi*vj for vj in vpv_list] for vi in vpv_list]
        vp = [vi*e for vi in vpv_list]
        return cvec, mp, vp, e, e2

    def save_ansatz(self):
        with h5py.File("ansatz.h5", "w") as f:
            # initial state params
            f["/params"] = self._params_init
            # ansatz operator labels
            f["/ansatz_code"] = self._ansatz[1]
            # ngates
            f["/ngates"] = self._ngates
            # reference state
            f["/ref_state"] = self._ref_state


    def minv_error(m, minv):
        n = m.shape[0]
        res = minv.dot(m)
        res = numpy.max(numpy.abs(res - numpy.eye(n)))
        return res


    def get_minv(a, delta=1.e-6):
        ap = a + delta*numpy.eye(a.shape[0])
        ainv = numpy.linalg.pinv(ap)
        return ainv


    def fun_cost(params, ansatz, ref_state, h):
        state = get_ansatz_state(params, ansatz, ref_state)
        res = h.matrix_element(state, state)
        return res.real


    def fun_jac(params, ansatz, ref_state, h):
        # - d <var|h|var> / d theta
        np = len(ansatz)
        vec = get_ansatz_state(params, ansatz, ref_state)
        opdense = isinstance(vec, numpy.ndarray)
        # <vec|h
        if opdense:
            h_vec = h.dot(vec)
        else:
            h_vec = h*vec

        jac = []
        state_i = ref_state
        if opdense:
            for i in range(np):
                op = ansatz[i]
                state_i = op.expm(-0.5j*params[i]).dot(state_i)
                state = op.dot(state_i)
                for theta, op in zip(params[i+1:], ansatz[i+1:]):
                    state = op.expm(-0.5j*theta).dot(state)
                zes = numpy.vdot(h_vec, state)
                jac.append(zes.imag)
        else:
            for i in range(np):
                opth = -0.5j*params[i]*ansatz[i]
                state_i = opth.expm()*state_i
                state = op*state_i
                for theta, op in zip(params[i+1:], ansatz[i+1:]):
                    opth = -0.5j*theta*op
                    state = opth.expm()*state
                zes = h_vec.overlap(state)
                jac.append(zes.imag)
        res = numpy.array(jac)
        return res


    def get_ansatz_state(params, ansatz, ref_state):
        state = ref_state
        opdense = isinstance(state, numpy.ndarray)
        #pdb.set_trace()
        for theta, op in zip(params, ansatz):
            #if opdense:
            opth_expm = op.expm(-0.5j*theta)
            state = opth_expm.dot(state)
            #else:
            #    opth = -0.5j*theta*op
            #    state = opth.expm()*state
        #pdb.set_trace()
        return state

    def rotate_z(pstring):
        for i, t in enumerate(pstring):
            if i%2==1:
                if t == 2: # make Y to X
                    pstring[i] = 1
                elif t == 1: # make X to Y

                    pstring[i] = 2



#@timeit
    def generate_op_pools(nq,
            order,
            pool,
            ):
        #from model import get_sxyz_ops
        sops_list = get_sxyz_ops(nq)

        # operator and label
        op_pools = []
        op_pool = [[], []]
        sind_temp = numpy.zeros(order*2, dtype=numpy.int)
        if pool is None or pool[0] == '-':
            for iorder in range(0,order):
            #for iorder in range(order-1,order):
                for ii in itertools.combinations(range(nq), iorder+1):
                    for ss in itertools.product(range(3), repeat=iorder+1):
                        if ss.count(1)%2 == 0:
                            continue
                        op = 1
                        sind = sind_temp.copy()
                        for n, i, s in zip(itertools.count(), ii, ss):
                            op *= sops_list[s][i]
                            sind[2*n:2*n+2] = [i, s+1]
                        op_pool[0].append(op)
                        op_pool[1].append(sind)
            op_pools.append(op_pool)

    # Apply Z-axis rotation symmetry
    #num_cores = multiprocessing.cpu_count()
    '''
    t0 = time.time()
    for term in op_pools[0][1]:
        #print(term)
        x = copy.deepcopy(term)
        rotate_z(x)
        #idx = Parallel(n_jobs=num_cores)\
        #     (delayed(int)(i) for i,s in enumerate(op_pools[0][1]) if str(x) == str(s) )
        idx = [i for i,s in enumerate(op_pools[0][1]) if str(x) == str(s)]
        #if len(idx)>0:
        #    print(idx)
            #pdb.set_trace()
        for i in idx[0:]:
            del op_pools[0][0][i]
            del op_pools[0][1][i]

    t1 = time.time()
    print(f'Z-rotation symmetry applied in {t1-t0}sec.')
    #'''



        print(f"op pool size: {len(op_pool[0])} for op_pool in op_pools")
        #pdb.set_trace()
        return op_pools


    def generate_op_pools_jw(nq,
            order,
            pool,
            ):
    '''
    recursively generates operator pool
    '''
        gate = ['I',"X","Y","Z"]

        if nq == 2:
            #op_pool = []
            #sind = [ [0,2,1,3,2,3],[0,0,1,2,2,3],[0,0,1,0,2,2],[0,0,1,2,2,0] ]
            sind = [ [0,2,1,3],[0,0,1,2] ]
            #op_pool = construct_string(sind)
            op_pool = construct_operator(sind,nq)
            op_str = construct_string(sind,nq)
            return [op_pool, sind, op_str]
        else:
            tmp = generate_op_pools_jw(nq-1, nq-1, None)
            sind = []
            #ss = []
            for term in tmp[1]:
                term.append(nq-1)
                term.append(3)
                sind.append(term)
            term1 = [0]*(2*nq)
            c = 0
            for t in range(len(term)):
                if t%2 == 0:
                    term1[t] = c
                    c += 1
            term1[2*nq-1] = 2

            term2 = [0]*(2*nq)
            c = 0
            for t in range(len(term)):
                if t%2 == 0:
                    term2[t] = c
                    c += 1
            term2[2*nq-3] = 2
            sind.append(term1)
            sind.append(term2)
            pool = construct_operator(sind,nq)
            pool_str = construct_string(sind,nq)
            #pdb.set_trace()
            return  [pool, sind, pool_str]


    def generate_op_pools_parity(nq,
            order,
            pool,
           ):
    '''
    recursively generates operator pool for parity encoding
    '''
        gate = ['I',"X","Y","Z"]

        if nq == 2:
            #op_pool = []
            sind = [[0,2,1,1], [0,2,1,0]]
            #op_pool = construct_string(sind)
            op_pool = construct_operator(sind,nq)
            return [op_pool, sind]
        else:
            tmp = generate_op_pools_parity(nq-1, nq-1, None)
            sind = []
            #ss = []
            for term in tmp[1]:
                term.append(nq-1)
                term.append(3)
                sind.append(term)
            term1 = [0]*(2*nq)
            c = 0
            for t in range(len(term)):
                if t%2 == 0:
                    term1[t] = c
                    c += 1
            term1[2*nq-1] = 2

            term2 = [0]*(2*nq)
            c = 0
            for t in range(len(term)):
                if t%2 == 0:
                    term2[t] = c
                    c += 1
            term2[2*nq-3] = 2
            sind.append(term1)
            sind.append(term2)
            pool = construct_operator(sind,nq)
            #pdb.set_trace()
            return  [pool, sind]

    def generate_op_pool_custom(nq,
            order,
            op_file_name,
            pool,
           ):
    '''
    read operators from a custom file
    '''
    #from model import get_sxyz_ops
        sops_list = get_sxyz_ops(nq)

        paulis = {'I':0,'X':1,'Y':2,'Z':3}
        # operator and label
        op_pools = []
        op_pool = [[], []]
        #'''
        f0 = open(op_file_name,"r")
        while True:
            line = f0.readline().strip()
            if len(line) < 1:
                break
            #print(line)
            sind = []
            for site, pauli in enumerate(list(line)):
                sind.append(nq-1-site)
                sind.append(paulis[pauli])
            # remove terms with even number of Y terms
            if sind[1::2].count(2)%2 == 0:
                print(line)
                #pdb.set_trace()
                continue
            #print(sind)
            op = construct_single_operator(sind, nq)
            #p_string = construct_single_string(sind, nq)
            #print(p_string)
            op_pool[0].append(op)
            op_pool[1].append(sind)
            #pdb.set_trace()
        op_pools.append(op_pool)


    # Apply Z-axis rotation symmetry
    #'''
        for term in op_pools[0][1]:
            print(term)
            print(len(op_pools[0][1]))
            x = copy.deepcopy(term)
            rotate_z(x)
            #pdb.set_trace()
            #idx = Parallel(n_jobs=num_cores)\
            #     (delayed(int)(i) for i,s in enumerate(op_pools[0][1]) if str(x) == str(s) )
            idx = [i for i,s in enumerate(op_pools[0][1]) if str(x) == str(s)]
            #if len(idx)>0:
            #    print(idx)
               #pdb.set_trace()
            for i in idx[0:]:
                del op_pools[0][0][i]
                del op_pools[0][1][i]

        print(len(op_pools[0][0]))
        f0.close()
    #'''


        print(f"op pool size: {len(op_pool[0])} for op_pool in op_pools")
        #pdb.set_trace()
        return op_pools


if __name__=='__main__':

    n = bin2dec('001001')
    print(n)
    #ans1 = generate_op_pools_jw(4,4,None)
    #ans1 = generate_op_pools_parity(2,2,None)
    ans2 = generate_op_pool_custom(8,6,'uccsd_pool_nq8.dat',None)
    #print(ans1)
    #pdb.set_trace()
    #print(ans2)





# It deals with quantum circuit with unbound parameter values
from quri_parts.circuit import LinearMappedUnboundParametricQuantumCircuit
from quri_parts.core.operator.representation import (
    BinarySymplecticVector,
    pauli_label_to_bsv,
    transition_amp_representation,
    transition_amp_comp_basis,
)
from quri_parts.core.state import ComputationalBasisState, ParametricCircuitQuantumState
import numpy as np
import scipy
from scipy.sparse import coo_matrix
from random import randint

sys.path.append("../")
from utils.challenge_2024 import ChallengeSampling, ExceededError, problem_hamiltonian

challenge_sampling = ChallengeSampling()


class ADAPT_QSCI:
    def __init__(
        self,
        hamiltonian: Operator,
        pool: list[Operator],
        n_qubits: int,
        n_ele_cas: int,
        sampler,
        iter_max: int = 10,
        sampling_shots: int = 10**4,
        post_selected: bool = True,
        atol: float = 1e-5,
        round_op_config: Union[dict, Tuple[Optional[int], Optional[float]]] = (None, 1e-2),
        num_precise_gradient=None,
        max_num_converged: int = 1,
        final_sampling_shots_coeff: float = 1.0,
        check_duplicate: bool = True,
        reset_ignored_inx_mode: int = 10,
    ):
        self.hamiltonian: Operator = hamiltonian
        self.pool: list[Operator] = pool
        self.n_qubits: int = n_qubits
        self.n_ele_cas: int = n_ele_cas
        self.iter_max: int = iter_max
        self.sampling_shots: int = sampling_shots
        self.atol: float = atol
        self.sampler = sampler
        self.post_selected: bool = post_selected
        self.check_duplicate: bool = check_duplicate
        # initialization
        hf_state = ComputationalBasisState(self.n_qubits, bits=2 ** self.n_ele_cas - 1)
        self.hf_state = hf_state
        self.comp_basis = [hf_state]
        # gradient
        if round_op_config is None:
            round_op_config = (None, None)
        num_pickup: int = round_op_config["num_pickup"] if isinstance(round_op_config, dict) else round_op_config[0]
        coeff_cutoff: float = round_op_config["cutoff"] if isinstance(round_op_config, dict) else round_op_config[1]
        self.num_pickup = num_pickup
        self.coeff_cutoff = coeff_cutoff
        round_ham = round_hamiltonian(hamiltonian, num_pickup=num_pickup, coeff_cutoff=coeff_cutoff)
        self.round_hamiltonian = round_ham
        self._is_grad_round: bool = not (num_pickup is None and coeff_cutoff is None)
        self.gradient_pool: List[Operator] = [commutator(round_ham, op) for op in pool]
        self.precise_grad_vals_mem: dict = {}
        self.gradient_vector_history = []
        self.num_precise_gradient: int = len(pool) if num_precise_gradient is None else num_precise_gradient
        self.pauli_rotation_circuit_qsci = PauliRotationCircuit([], [], [], n_qubits)
        self.ignored_gen_inx = []
        self.reset_ignored_inx_mode: int = reset_ignored_inx_mode if reset_ignored_inx_mode > 0 else iter_max
        # convergence
        assert max_num_converged >= 1
        self.final_sampling_shots: int = int(final_sampling_shots_coeff * sampling_shots)
        self.max_num_converged: int = max_num_converged
        self.num_converged: int = 0
        # results
        self.qsci_energy_history: list = []
        self.opt_energy_history: list = []
        self.operator_index_history: list = []
        self.gradient_history: list = []
        self.param_values: list = []
        self.raw_energy_history = []
        self.sampling_results_history = []
        self.comp_basis_history = []
        self.opt_param_value_history = []
        self.generator_history: list = []
        self.generator_qubit_indices_history: list = []

    def _get_optimized_parameter(
        self, vec_qsci: np.ndarray, comp_basis: list[ComputationalBasisState]
    ) -> float:
        
        # ansatz operators 
        generator_qp = self.pool[self.operator_index_history[-1]]
        ham_sparse = generate_truncated_hamiltonian(self.hamiltonian, comp_basis)
        commutator_sparse = generate_truncated_hamiltonian(
            1j * self.precise_grad_vals_mem[self.operator_index_history[-1]], comp_basis
        )
        exp_h = (vec_qsci.T.conj() @ ham_sparse @ vec_qsci).item().real
        exp_commutator = (
            (vec_qsci.T.conj() @ commutator_sparse @ vec_qsci).item().real
        )
        php = generator_qp * self.hamiltonian * generator_qp
        php_sparse = generate_truncated_hamiltonian(php, comp_basis)
        exp_php = (vec_qsci.T.conj() @ php_sparse @ vec_qsci).item().real
        cost_e2 = (
            lambda x: exp_h * np.cos(x[0]) ** 2
            + exp_php * np.sin(x[0]) ** 2
            + exp_commutator * np.cos(x[0]) * np.sin(x[0])
        )
        result_qsci = scipy.optimize.minimize(
            cost_e2, np.array([0.0]), method="BFGS", options={"disp": False, "gtol": 1e-6}
        )
        try:
            assert result_qsci.success
        except:
            print("try optimization again...")
            result_qsci = scipy.optimize.minimize(
                cost_e2, np.array([0.1]), method="BFGS", options={"disp": False, "gtol": 1e-6}
            )
            if not result_qsci.success:
                print("*** Optimization failed, but we continue calculation. ***")
        print(f"θ: {result_qsci.x}")
        return float(result_qsci.x)

    def run(self) -> float:
        # getting the hamiltonain's energy state and energy value
        vec_qsci, val_qsci = diagonalize_effective_ham(self.hamiltonian, self.comp_basis)
        self.qsci_energy_history.append(val_qsci)
    
        for itr in range(1, self.iter_max + 1):
            print(f"iteration: {itr}")
            # values of all gradient operator that will be found and stored here. 
            grad_vals = np.zeros(len(self.pool), dtype=float)
            
            # j is the complex component of the grad, which is the gradient value of the gradient operator from the pool.
            for j, grad in enumerate(self.gradient_pool):
                
                # creating a gradient matrix for an individual gradient operator, which is also truncated for efficiency. 
                grad_mat = generate_truncated_hamiltonian(1j * grad, self.comp_basis)
                
                # storing the gradient which is also the expectation value of the matrix with respect to its influence on the eigenstate
                grad_vals[j] = (vec_qsci.T @ grad_mat @ vec_qsci).real
            
            # stores the most influencial gradient operators by the ascending order of their absolute values. 
            sorted_indices = np.argsort(np.abs(grad_vals))[::-1]

            # find largest index of generator
            precise_grad_vals = {}
            if self.num_precise_gradient is not None and self._is_grad_round:
                # calculate the precise value of gradient
                for i_ in list(sorted_indices):
                    if i_ not in self.ignored_gen_inx:
                        
                        # checking for cached storage of precise gradients  
                        if i_ in self.precise_grad_vals_mem.keys():
                            grad = self.precise_grad_vals_mem[i_]
                            
                        # otherwise calculating it using the commutator of the hamiltonian and the operator from the pool.
                        else:
                            grad = commutator(self.hamiltonian, self.pool[i_])
                            self.precise_grad_vals_mem[i_] = grad
                        grad_val = (
                            vec_qsci.T
                            @ generate_truncated_hamiltonian(1j * grad, self.comp_basis)
                            @ vec_qsci
                        )
                        precise_grad_vals[i_] = grad_val
                    else:
                        pass
                    if len(precise_grad_vals.keys()) >= self.num_precise_gradient:
                        break
                # print(precise_grad_vals)
                sorted_keys = sorted(precise_grad_vals.keys(), key=lambda x: abs(precise_grad_vals[x]), reverse=True)
                assert len(sorted_keys) == self.num_precise_gradient

                # select generator whose abs. gradient is second largest when same generator is selected twice in a row
                if self.check_duplicate:
                    if (len(self.operator_index_history) >= 1 and len(sorted_keys) >= 2) and \
                            (sorted_keys[0] == self.operator_index_history[-1]):
                        largest_index: int = sorted_keys[1]
                        print("selected second largest gradient")
                        self.ignored_gen_inx.append(sorted_keys[0])
                        print(f"index {sorted_keys[0]} added to ignored list")
                    else:
                        largest_index: int = sorted_keys[0]
                else:
                    largest_index = sorted_indices[0]
                grad_vals = precise_grad_vals.values()
                print(
                    f"new generator: {str(self.pool[largest_index]).split('*')}, index: {largest_index} "
                    f"out of {len(self.pool)}. # precise gradient: {self.num_precise_gradient}"
                )
                self.gradient_vector_history.append(key_sortedabsval(precise_grad_vals))
            else:
                largest_index = sorted_indices[0]
            # saving easy-to-access operators used for optimization from the pool
            self.operator_index_history.append(largest_index)
            
            self.gradient_history.append(np.abs(max(grad_vals)))
            operator_coeff_term = str(self.pool[largest_index]).split("*")
            new_coeff, new_pauli_str = float(operator_coeff_term[0]), operator_coeff_term[1]
            # adds pauli strings of only of the most impactful operators 
            self.generator_history.append(new_pauli_str)

            # add new generator to ansatz
            new_param_name = f"theta_{itr}"
            circuit_qsci = self.pauli_rotation_circuit_qsci.add_new_gates(new_pauli_str, new_coeff, new_param_name)
            new_param_value = self._get_optimized_parameter(vec_qsci, self.comp_basis)
            
            # checking if the newly added parameterized gate is zero, if so then it is ignored and discarded. 
            if np.isclose(new_param_value, 0.):
                self.ignored_gen_inx.append(largest_index)
                print(f"index {largest_index} added to ignored list")
            self.opt_param_value_history.append(new_param_value)
            
            # Checking if there is any fusion memory (common parameters), then new parameter is added to existing one. 
            if self.pauli_rotation_circuit_qsci.fusion_mem:
                self.param_values[
                    self.pauli_rotation_circuit_qsci.fusion_mem[0]
                ] += new_param_value
            else:
                if np.isclose(0.0, new_param_value):
                    circuit_qsci = self.pauli_rotation_circuit_qsci.delete_newest_gate()
                else:
                    self.param_values.append(new_param_value)
                    
            # storing the indeces of the qubits targetted by the last gate, if it still exists in the ansatz. 
            
            try:
                new_gen_indices = sorted(circuit_qsci.gates[-1].target_indices)
            except IndexError:
                print(f"ansatz seems to have no gates since optimized parameter was {new_param_value}")
                raise

            # increase sampling shots when same generator is selected twice in a row or parameter is close to 0.
            is_alert = new_gen_indices in self.generator_qubit_indices_history or np.isclose(0.0, new_param_value)
            self.generator_qubit_indices_history.append(new_gen_indices)
            sampling_shots = self.final_sampling_shots if is_alert else self.sampling_shots

            # prepare circuit for QSCI
            
            # Setting up an initial quantum state in computational basis. 
            parametric_state_qsci = prepare_parametric_state(self.hf_state, circuit_qsci)
            # Binding parameters to their corresponding placeholders in parameterized quantum state.
            target_circuit = parametric_state_qsci.parametric_circuit.bind_parameters(self.param_values)
            # Refining the circuit for accurate execution on quantum hardware. 
            transpiled_circuit = RZSetTranspiler()(target_circuit)

            # QSCI
            try:
                # smapling shots counted from the prepared circuit containing all the optimized added parameters to our ansatz
                counts = self.sampler(transpiled_circuit, sampling_shots)
            except ExceededError as e:
                # if computational resources have been exceeded, fall back onto previous QSCI energy
                print(str(e))
                return min(self.qsci_energy_history)
            
            # optimize computational basis; the heart of selecting basis for finding the ground state. 
            self.comp_basis = pick_up_bits_from_counts(
                counts=counts,
                n_qubits=self.n_qubits,
                R_max=num_basis_symmetry_adapted_cisd(self.n_qubits),
                threshold=1e-10,
                post_select=self.post_selected,
                n_ele=self.n_ele_cas,
            )
            self.sampling_results_history.append(counts)
            self.comp_basis_history.append(self.comp_basis)
            vec_qsci, val_qsci = diagonalize_effective_ham(
                self.hamiltonian, self.comp_basis
            )
            self.qsci_energy_history.append(val_qsci)
            print(f"basis selected: {[bin(b.bits)[2:].zfill(self.n_qubits) for b in self.comp_basis]}")
            print(f"QSCI energy: {val_qsci}, (new generator {new_pauli_str})")

            # terminate condition
            if (
                abs(self.qsci_energy_history[-2] - self.qsci_energy_history[-1])
                < self.atol
            ):
                self.num_converged += 1
                # If the energy convergence has occured a sufficient number of times, terminate. 
                if self.num_converged == self.max_num_converged:
                    break
                else:
                    continue

            # empty ignored index list periodically
            if itr % self.reset_ignored_inx_mode == 0:
                print(f"ignored list emptied: {self.ignored_gen_inx} -> []")
                self.ignored_gen_inx = []
        return min(self.qsci_energy_history)


class PauliRotationCircuit:
    def __init__(
        self, generators: list, coeffs: list, param_names: list, n_qubits: int
    ):
        self.generators: list = generators
        self.coeffs: list = coeffs
        self.param_names: list = param_names
        self.n_qubits: int = n_qubits
        self.fusion_mem: list = []
        self.generetors_history: list = []

    def __call__(self):
        return self.construct_circuit()

    def construct_circuit(
        self, generators=None
    ) -> LinearMappedUnboundParametricQuantumCircuit:
        # This is where the ansatz begins. 
        circuit = LinearMappedUnboundParametricQuantumCircuit(self.n_qubits)
        
        # Using its own list of back-up generators if none are provided.
        if generators is None:
            generators = self.generators
        for generator, coeff, name in zip(generators, self.coeffs, self.param_names):
            # adding generator parameter name
            param_name = circuit.add_parameter(name)
            # converting generator's format properly 
            if isinstance(generator, str):
                generator = pauli_label(generator)
            else:
                raise
            # extracting the relevant details from the generator
            pauli_index_list, pauli_id_list = zip(*generator)
            coeff = coeff.real
            # using those details to add parametric gates to the ansatz/circuit. 
            circuit.add_ParametricPauliRotation_gate(
                pauli_index_list,
                pauli_id_list,
                {param_name: -2.0 * coeff},
            )
        return circuit

    def add_new_gates(
        self, generator: str, coeff: float, param_name: str
    ) -> LinearMappedUnboundParametricQuantumCircuit:
        self._reset()
        self.generetors_history.append(generator)
        # runs the list of generators backwards, implying that the most recent ones are most relevant
        for i, (g, n) in enumerate(zip(self.generators[::-1], self.param_names[::-1])):
            
            # Checking if it's 'fused' with any other generator
            if is_equivalent(generator, g):
                self.fusion_mem = [-i]
                print(f"FUSED: {g, generator}")
                break
            # Checking if the generator commutes
            elif is_commute(generator, g):
                continue
            # If neither are satisfied, it breaks. 
            else:
                break
        if not self.fusion_mem:
            self.generators.append(generator)
            self.coeffs.append(coeff)
            self.param_names.append(param_name)
        return self.construct_circuit()

    def delete_newest_gate(self) -> LinearMappedUnboundParametricQuantumCircuit:
        self._reset()
        self.generators = self.generators[:-1]
        self.coeffs = self.coeffs[:-1]
        self.param_names = self.param_names[:-1]
        return self.construct_circuit()

    def _reset(self):
        self.fusion_mem = []


def diagonalize_effective_ham(
    ham_qp: Operator, comp_bases_qp: list[ComputationalBasisState]
) -> Tuple[np.ndarray, np.ndarray]:
    effective_ham_sparse = generate_truncated_hamiltonian(ham_qp, comp_bases_qp)
    assert np.allclose(effective_ham_sparse.todense().imag, 0)
    effective_ham_sparse = effective_ham_sparse.real
    if effective_ham_sparse.shape[0] > 10:
        eig_qsci, vec_qsci = scipy.sparse.linalg.eigsh(
            effective_ham_sparse, k=1, which="SA"
        )
        eig_qsci = eig_qsci.item()
        vec_qsci = vec_qsci.squeeze()
    else:
        eig_qsci, vec_qsci = np.linalg.eigh(effective_ham_sparse.todense())
        eig_qsci = eig_qsci[0]
        vec_qsci = np.array(vec_qsci[:, 0])

    return vec_qsci, eig_qsci


def generate_truncated_hamiltonian(
    hamiltonian: Operator,
    states: Sequence[ComputationalBasisState],
) -> scipy.sparse.spmatrix:
    """Generate truncated Hamiltonian on the given basis states."""
    dim = len(states)
    # storing transition amplitudes between pair states
    values = []
    row_ids = []
    column_ids = []
    h_transition_amp_repr = transition_amp_representation(hamiltonian)
    # for efficient pairings; no repetitions.
    for m in range(dim):
        for n in range(m, dim):
            # transition amplitude between the two pair states (m and n)
            mn_val = transition_amp_comp_basis(
                h_transition_amp_repr, states[m].bits, states[n].bits
            )
            if mn_val:
                values.append(mn_val)
                row_ids.append(m)
                column_ids.append(n)
                if m != n:
                    values.append(mn_val.conjugate())
                    row_ids.append(n)
                    column_ids.append(m)
    truncated_hamiltonian = coo_matrix(
        (values, (row_ids, column_ids)), shape=(dim, dim)
    ).tocsc(copy=False)
    truncated_hamiltonian.eliminate_zeros()

    return truncated_hamiltonian


def _add_term_from_bsv(
    bsvs: List[List[Tuple[int, int]]], ops: List[Operator]
) -> Operator:
    ret_op = Operator()
    op0_bsv, op1_bsv = bsvs[0], bsvs[1]
    op0, op1 = ops[0], ops[1]
    for i0, (pauli0, coeff0) in enumerate(op0.items()):
        for i1, (pauli1, coeff1) in enumerate(op1.items()):
            bitwise_string = str(
                bin(
                    (op0_bsv[i0][0] & op1_bsv[i1][1])
                    ^ (op0_bsv[i0][1] & op1_bsv[i1][0])
                )
            )
            if bitwise_string.count("1") % 2 == 1:
                pauli_prod_op, pauli_prod_phase = pauli_product(pauli0, pauli1)
                tot_coef = 2 * coeff0 * coeff1 * pauli_prod_phase
                ret_op.add_term(pauli_prod_op, tot_coef)
    return ret_op


def pauli_string_to_bsv(pauli_str: str) -> BinarySymplecticVector:
    return pauli_label_to_bsv(pauli_label(pauli_str))


def get_bsv(pauli: Union[PauliLabel, str]) -> BinarySymplecticVector:
    if isinstance(pauli, str):
        bsv = pauli_string_to_bsv(pauli)
    else:
        bsv = pauli_label_to_bsv(pauli)
    return bsv


def is_commute(pauli1: Union[PauliLabel, str], pauli2: Union[PauliLabel, str]) -> bool:
    bsv1 = get_bsv(pauli1)
    bsv2 = get_bsv(pauli2)
    x1_z2 = bsv1.x & bsv2.z
    z1_x2 = bsv1.z & bsv2.x
    is_bitwise_commute_str = str(bin(x1_z2 ^ z1_x2)).split("b")[-1]
    return sum(int(b) for b in is_bitwise_commute_str) % 2 == 0


def is_equivalent(
    pauli1: Union[PauliLabel, str], pauli2: Union[PauliLabel, str]
) -> bool:
    bsv1 = get_bsv(pauli1)
    bsv2 = get_bsv(pauli2)
    return bsv1.x == bsv2.x and bsv1.z == bsv2.z


def operator_bsv(op: Operator) -> List[Tuple[int, int]]:
    ret = []
    for pauli in op.keys():
        bsv_pauli = get_bsv(pauli)
        ret.append((bsv_pauli.x, bsv_pauli.z))
    return ret


def round_hamiltonian(op: Operator, num_pickup: int = None, coeff_cutoff: float = None):
    ret_op = Operator()
    if coeff_cutoff in [None, 0.0] and num_pickup is None:
        return op
    # sorting operators from strongest to weakest 
    sorted_pauli = sorted(op.keys(), key=lambda x: abs(op[x]), reverse=True)
    
    # limiting number of terms 
    if num_pickup is not None:
        sorted_pauli = sorted_pauli[:num_pickup]
        
    # strength threshold 
    if coeff_cutoff is None:
        coeff_cutoff = 0
        
    # adding the operators to the overall ret(urn) operator    
    for pauli in sorted_pauli:
        coeff = op[pauli]
        if abs(coeff) < coeff_cutoff:
            pass
        else:
            ret_op += Operator({pauli: coeff})
    return ret_op


def commutator(
    op0: Union[Operator, float, int, complex], op1: Union[Operator, float, int, complex]
) -> Operator:
    # checkes if the current operator(s) in question are an instance of the overall Operator class
    if not isinstance(op0, Operator) or not isinstance(op1, Operator):
        return Operator({PAULI_IDENTITY: 0.0}) # if not, then the operator is effectively 0.
    else:
        # If it is, you then establish their corresponding BSVs and add them to the overall operator. 
        assert isinstance(op0, Operator) and isinstance(op1, Operator)
        op0_bsv = operator_bsv(op0)
        op1_bsv = operator_bsv(op1)
        ret_op = _add_term_from_bsv([op0_bsv, op1_bsv], [op0, op1])
        return ret_op


def prepare_parametric_state(initial_state, ansatz):
    circuit = LinearMappedUnboundParametricQuantumCircuit(initial_state.qubit_count)
    circuit += initial_state.circuit
    circuit += ansatz
    return ParametricCircuitQuantumState(initial_state.qubit_count, circuit)


def key_sortedabsval(data: Union[list, dict, np.ndarray], round_: int = 5) -> dict:
    if isinstance(data, dict):
        sorted_keys = sorted(data.keys(), key=lambda x: abs(data[x]), reverse=True)
    else:
        sorted_keys = np.argsort(np.abs(data))[::-1]
    ret_dict = {}
    for k in sorted_keys:
        val = float(data[int(k)].real)
        assert np.isclose(val.imag, 0.0)
        ret_dict[int(k)] = round(val, round_)
    return ret_dict


def create_qubit_adapt_pool_XY_XXXY(
    # setting up initial parameters 
    n_qubits,
    use_singles: bool = False,
    single_excitation_dominant: bool = False,
    double_excitation_dominant: bool = False,
    mode: list[int] = None,
    n_electrons: int = None,
    
    # creating operator qubits 
) -> list[Operator]:
    operator_pool_qubit = []
    
    # if single implementation is dominant, run all combinations of the qubits accordingly and then apply the operator on it.
    if use_singles:
        for p, q in combinations(range(n_qubits), 2):
            if single_excitation_dominant and not (p < n_electrons <= q):
                continue
            operator_pool_qubit.append(QubitOperator(f"X{p} Y{q}", 1.0))
    if mode is None:
        mode = [0, 1, 2, 3]
    for m in mode:
        assert m in [0, 1, 2, 3, 4]
        if m == 4:
            mode = [4]
            break
    for p, q, r, s in combinations(range(n_qubits), 4):
        # checking for double implementation being dominant. 
        if double_excitation_dominant and not (q < n_electrons <= r):
            continue
        # each mode has some pre-defined correspondence to a pauli operation type. 
        for m in mode:
            x_index = m if m in [0, 1, 2, 3] else randint(0, 3)
            p_list = ["Y" if _ == x_index else "X" for _ in range(4)]
            gen_string_list = " ".join(
                [f"{p}{i}" for p, i in zip(p_list, (p, q, r, s))]
            )
            operator_pool_qubit.append(QubitOperator(gen_string_list, 1.0))
    operator_pool_qubit = [
        operator_from_openfermion_op(op) for op in operator_pool_qubit
    ]
    return operator_pool_qubit

# Makes use of CISD as well as important symmetry applications. 
def num_basis_symmetry_adapted_cisd(n_qubits: int):
    return (n_qubits**4 - 4 * n_qubits**3 + 20 * n_qubits**2 + 64) // 64


def pick_up_bits_from_counts(
    
    # necessary criteria 
    counts: Mapping[int, Union[int, float]],
    n_qubits,
    R_max=None,
    threshold=None,
    post_select=False,
    n_ele=None,
): 
    
    # an initial list of keys that occur most frequently. 
    sorted_keys = sorted(counts.keys(), key=lambda x: counts[x], reverse=True)
    if threshold is None:
        heavy_bits = sorted_keys
    else:
        # refining the sorted_keys list into heavy_bits list using the threshold criteria. 
        heavy_bits = [bit for bit in sorted_keys if counts[bit] >= threshold]
    
    if post_select:
        assert n_ele is not None
        # further refinement as post-selection for those heavy_bits that only have n_ele number of electrons. 
        heavy_bits = [i for i in heavy_bits if bin(i).count("1") == n_ele]
    if R_max is not None:
        # an even further refinement of the heavy_bits by capping them off at a particular R_max value. 
        heavy_bits = heavy_bits[:R_max]
    
    comp_bases_qp = [
        ComputationalBasisState(n_qubits, bits=int(key)) for key in heavy_bits
    ]
    return comp_bases_qp


class RunAlgorithm:
    def __init__(self) -> None:
        challenge_sampling.reset()

    def result_for_evaluation(self, seed: int, hamiltonian_directory: str) -> tuple[Any, float]:
        energy_final = self.get_result(seed, hamiltonian_directory)
        total_shots = challenge_sampling.total_shots
        return energy_final, total_shots

    def get_result(self, seed: int, hamiltonian_directory: str) -> float:
        """
            param seed: the last letter in the Hamiltonian data file, taking one of the values 0,1,2,3,4
            param hamiltonian_directory: directory where hamiltonian data file exists
            return: calculated energy.
        """
        n_qubits = 28
        ham = problem_hamiltonian(n_qubits, seed, hamiltonian_directory)
        n_electrons = n_qubits // 2
        use_singles = True
        jw_hamiltonian = jordan_wigner(ham)
        qp_hamiltonian = operator_from_openfermion_op(jw_hamiltonian)
        num_pickup, coeff_cutoff = 100, 0.001
        post_selection = False
        mps_sampler = challenge_sampling.create_sampler()
        pool = create_qubit_adapt_pool_XY_XXXY(
            n_qubits,
            use_singles=use_singles,
            single_excitation_dominant=True,
            double_excitation_dominant=True,
            mode=[4],
            n_electrons=n_electrons,
        )
        adapt_qsci = ADAPT_QSCI(
            qp_hamiltonian,
            pool,
            n_qubits=n_qubits,
            n_ele_cas=n_electrons,
            sampler=mps_sampler,
            iter_max=100,
            post_selected=post_selection,
            sampling_shots=10**5,
            atol=1e-6,
            final_sampling_shots_coeff=5,
            round_op_config=(num_pickup, coeff_cutoff),
            num_precise_gradient=128,
            max_num_converged=2,
            check_duplicate=True,
            reset_ignored_inx_mode=0,
        )
        res = adapt_qsci.run()
        return res


if __name__ == "__main__":
    run_algorithm = RunAlgorithm()
    print(run_algorithm.get_result(seed=0, hamiltonian_directory="../hamiltonian"))
