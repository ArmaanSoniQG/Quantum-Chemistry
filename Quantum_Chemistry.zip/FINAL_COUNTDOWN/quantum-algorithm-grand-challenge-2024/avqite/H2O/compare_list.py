import os
import sys

def rotate_z(pstring):
    for i, t in enumerate(pstring):
        if t == 1: # make Y to X
            pstring[i] = 0
        elif t == 0: # make X to Y
            pstring[i] = 1



l1 = [1,2,1,0]
l2 = [2,2,1,3]
l3 = [1,2,3,1]

ll = [l1,l2,l3]
print(str(ll))
print(l1)
rotate_z(l1)

print(l1)

print("")
l1 = str(l1)
l2 = str(l2)
l3 = str(l3)
print(l1)
print(l2)
print(l1==l3)
