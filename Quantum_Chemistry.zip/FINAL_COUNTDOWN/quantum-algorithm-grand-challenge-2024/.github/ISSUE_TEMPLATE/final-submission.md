---
name: Final Submission
about: A template for submitting your Quantum Algorithm Grand Challenge project
title: "[ENTRY] Your Project Title"
labels: ''
assignees: ''

---

## Team name: 
Your team's name 

## Team members: 
List up all members' name 

## Project Description: 
A brief description of your project (1-2 paragraphs). 

## Presentation:
A link of presentation with slides of your team’s hackathon project.

## Source code: 
A link to the final source code for your team's hackathon project (e.g., a GitHub repo).

## Your score (Optional)
This will be used for reference during score evaluation. The results from less than ten calculation are also acceptable